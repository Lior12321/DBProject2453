--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mydatabase;
--
-- Name: mydatabase; Type: DATABASE; Schema: -; Owner: lior
--

CREATE DATABASE mydatabase WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mydatabase OWNER TO lior;

\connect mydatabase

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: classrooms; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.classrooms (
    class_id integer NOT NULL,
    class_name character varying(50) NOT NULL,
    class_building character varying(50) NOT NULL,
    course_id integer NOT NULL,
    professor_id integer NOT NULL
);


ALTER TABLE public.classrooms OWNER TO lior;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.courses (
    course_id integer NOT NULL,
    course_name character varying(50) NOT NULL,
    credits integer NOT NULL
);


ALTER TABLE public.courses OWNER TO lior;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(50) NOT NULL,
    head_professor_id integer,
    department_building character varying(50) NOT NULL
);


ALTER TABLE public.departments OWNER TO lior;

--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.enrollments (
    enrollment_id integer NOT NULL,
    enrollment_date date NOT NULL,
    enrollment_price integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL
);


ALTER TABLE public.enrollments OWNER TO lior;

--
-- Name: grades; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.grades (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    grade integer NOT NULL,
    grade_date date NOT NULL,
    pass_fail character varying(4) NOT NULL
);


ALTER TABLE public.grades OWNER TO lior;

--
-- Name: professors; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.professors (
    professor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    hireing_date date NOT NULL,
    wage integer NOT NULL,
    mail_address character varying(50) NOT NULL,
    department_id integer NOT NULL
);


ALTER TABLE public.professors OWNER TO lior;

--
-- Name: students; Type: TABLE; Schema: public; Owner: lior
--

CREATE TABLE public.students (
    student_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    birth_date date NOT NULL,
    mail_address character varying(50) NOT NULL
);


ALTER TABLE public.students OWNER TO lior;

--
-- Data for Name: classrooms; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.classrooms (class_id, class_name, class_building, course_id, professor_id) FROM stdin;
\.
COPY public.classrooms (class_id, class_name, class_building, course_id, professor_id) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.courses (course_id, course_name, credits) FROM stdin;
\.
COPY public.courses (course_id, course_name, credits) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.departments (department_id, department_name, head_professor_id, department_building) FROM stdin;
\.
COPY public.departments (department_id, department_name, head_professor_id, department_building) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.enrollments (enrollment_id, enrollment_date, enrollment_price, student_id, course_id) FROM stdin;
\.
COPY public.enrollments (enrollment_id, enrollment_date, enrollment_price, student_id, course_id) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.grades (student_id, course_id, grade, grade_date, pass_fail) FROM stdin;
\.
COPY public.grades (student_id, course_id, grade, grade_date, pass_fail) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: professors; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.professors (professor_id, first_name, last_name, hireing_date, wage, mail_address, department_id) FROM stdin;
\.
COPY public.professors (professor_id, first_name, last_name, hireing_date, wage, mail_address, department_id) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: lior
--

COPY public.students (student_id, first_name, last_name, birth_date, mail_address) FROM stdin;
\.
COPY public.students (student_id, first_name, last_name, birth_date, mail_address) FROM '$$PATH$$/3405.dat';

--
-- Name: classrooms classrooms_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_pkey PRIMARY KEY (class_id);


--
-- Name: courses courses_course_name_key; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_course_name_key UNIQUE (course_name);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (enrollment_id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (student_id, course_id);


--
-- Name: professors professors_mail_address_key; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_mail_address_key UNIQUE (mail_address);


--
-- Name: professors professors_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_pkey PRIMARY KEY (professor_id);


--
-- Name: students students_mail_address_key; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_mail_address_key UNIQUE (mail_address);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: classrooms classrooms_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: classrooms classrooms_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.professors(professor_id);


--
-- Name: enrollments enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: enrollments enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(student_id);


--
-- Name: grades grades_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: grades grades_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(student_id);


--
-- Name: professors professors_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lior
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- PostgreSQL database dump complete
--

